package com.master.vibe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VibeApplicationTests {

	@Test
	void contextLoads() {
	}

}
