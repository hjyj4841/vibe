package com.master.vibe.service;

import org.springframework.stereotype.Service;

@Service
public class PlaylistLikeService {

}
