package mapper;


public interface TagMapper {

}
